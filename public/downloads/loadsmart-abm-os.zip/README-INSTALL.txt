Loadsmart GTM Agent OS — Complete Team Kit
==========================================
1. kit/skills/*           — All portable SKILL.md folders (upload individual ZIPs or unzip here)
2. automations/n8n/*      — Import 00-loadsmart-6step-prospect-engine.json + 05 error handler
3. automations/prompts/*  — Paste loadsmart-n8n-setup-prompt.md into Claude Code / Chat
4. kit/config/*           — Territory, ICP, exclusion, and cadence rules
5. knowledge/loadsmart/*  — Approved Claims Library (C-XXX)